"""
OpenTimelineIO-Plugins is a stub package for the "batteries-included"
OpenTimelineIO install.
"""
